<?php
defined('_JEXEC') || die('<html><head><script>location.href = location.origin</script></head></html>');

echo
      '</div>',
    '</main>',
    $this->getBuffer('modules', 'footer', []),
  '</body>',
'</html>';
